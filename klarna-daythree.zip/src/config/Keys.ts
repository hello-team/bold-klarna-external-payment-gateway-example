const keys = {
  host: 'localhost', // MySQL host
  user: 'your_username', // MySQL username
  password: 'your_password', // MySQL password
  database: 'your_database', // MySQL database name
};

export default keys;
