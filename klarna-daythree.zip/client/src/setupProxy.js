const { createProxyMiddleware } = require('http-proxy-middleware');

module.exports = function (app) {
  app.use(
    '/api', // WebSocket endpoint
    createProxyMiddleware({
      target: 'http://localhost:9000', // Replace with your Express server URL
      ws: false,
      secure: false, // If using a self-signed SSL certificate, set secure to false
      changeOrigin: true,
    })
  );
};
