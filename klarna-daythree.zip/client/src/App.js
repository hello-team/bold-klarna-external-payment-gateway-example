import React, { useEffect, useState } from 'react';
import PaymentWidgetComponent from './PaymentWidgetComponent';
import styles from './styles/klarna-checkout-component.module.css';

const App = () => {
  const [showWidget, setShowWidget] = useState(false);
  const [applicationState, setApplicationState] = useState({})
  const [jwtToken, setJWTToken] = useState('')
  const [publicOrderId, setPublicOrderId] = useState('')
  const [paymentConfig, setPaymentConfig] = useState({})
  useEffect(() => {
    window.parent.postMessage(
      {
        type: 'EXTERNAL_PAYMENT_GATEWAY_INITIALIZED',
        payload: {
          success: true,
        },
      },
      '*'
    );


  }, []);

  const handleKlarnaButtonClick = () => {

    console.log('Button clicked');
    window.parent.postMessage(
      {
        type: 'EXTERNAL_PAYMENT_GATEWAY_INITIALIZED',
        payload: {
          success: true,
        },
      },
      '*'
    );
    setShowWidget(true);
  };



  useEffect(() => {
    const handleMessage = (event) => {
      const message = event.data;
      console.log({ event: event.data })

      if (message.type === 'EXTERNAL_PAYMENT_GATEWAY_SET_CONFIG' && message.payload) {
        setPaymentConfig(message.payload)
      }

      if (message.type === 'EXTERNAL_PAYMENT_GATEWAY_UPDATE_STATE' && message.payload) {
        // Handle the updated application state received from the iframe
        const { application_state, jwt_token, public_order_id } = message.payload;
        // TODO: Process the updated state as needed
        setApplicationState(application_state)
        setJWTToken(jwt_token)
        setPublicOrderId(public_order_id)
        console.log('Updated application state:', application_state);
      }
    };

    window.addEventListener('message', handleMessage);

    return () => {
      window.removeEventListener('message', handleMessage);
    };
  }, []);

  return (
    <div>
      <button
        id="klarna-payment-button"
        className={styles['klarna-payment-button']}
        onClick={handleKlarnaButtonClick}
      >
        Klarna Payment Button
      </button>
      <div id="klarna-widget">
        {showWidget && <PaymentWidgetComponent showWidget={showWidget} applicationState={applicationState} jwtToken={jwtToken} publicOrderId={publicOrderId} paymentConfig={paymentConfig} />}
      </div>
    </div>
  );
};

export default App;
