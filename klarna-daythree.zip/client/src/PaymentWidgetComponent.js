import React, { useEffect, useState, useRef } from 'react';
import styles from './styles/klarna-checkout-component.module.css';
import { addPayment, processOrder } from '@boldcommerce/checkout-frontend-library';
import { Modal, Button } from '@mui/material';

export default function PaymentWidgetComponent({ showWidget, applicationState, jwtToken, publicOrderId, paymentConfig }) {
  const [showAuthorizeBtn, setShowAuthorizeBtn] = useState(false);
  const [klarnaCart, setKlarnaCart] = useState(null);
  const [isAuthorized, setIsAuthorized] = useState(false);
  const authorizeButtonRef = useRef(null);

  const completePurchase = () => {
    window.parent.postMessage(
      {
        type: 'EXTERNAL_PAYMENT_GATEWAY_TOKENIZING_COMPLETED',
        payload: {
          success: true,
        },
      },
      '*'
    );
  };

  const authorizePayment = (event) => {
    event.preventDefault();

    window.Klarna.Payments.authorize(
      {
        payment_method_category: 'pay_over_time',
      },
      klarnaCart,
      function (res) {
        const authorization_token = res.authorization_token;
        if (authorization_token && !isAuthorized) {
          setIsAuthorized(true);

          window.parent.postMessage(
            {
              type: 'EXTERNAL_PAYMENT_GATEWAY_ADD_PAYMENT',
              payload: {
                amount: applicationState.order_total,
                currency: applicationState.currency.iso_code,
                display_string: 'klarna',
                retain: true,
                token: applicationState.order_meta_data.cart_parameters.klarna.session_id,
                type: 'CREDIT_CARD',
                gateway_public_id: paymentConfig.public_id,
                external_id: authorization_token,
                third_party_parameters: [{ public_order_id: publicOrderId, application_state: applicationState }]
              },
            },
            '*'
          );

          window.parent.postMessage(
            {
              type: 'EXTERNAL_PAYMENT_GATEWAY_REFRESH_ORDER'
            },
            '*'
          );
          window.parent.postMessage(
            {
              type: 'EXTERNAL_PAYMENT_GATEWAY_TOKENIZING_IN_PROGRESS',
              payload: {
                success: true,
              },
            },
            '*'
          );
          completePurchase();
        }
      }
    );
  };

  useEffect(() => {
    const handleMessage = (event) => {
      try {
        const message = event.data;
        console.log({ event });
        const cartParams = applicationState?.order_meta_data?.cart_parameters;
        console.log({
          cartParams
        })
        if (cartParams && cartParams.klarna && window.Klarna) {
          setKlarnaCart(cartParams.klarna.klarna_cart);
          const klarnaToken = cartParams.klarna.client_token;

          window.Klarna.Payments.init({ client_token: klarnaToken });

          window.Klarna.Payments.load(
            {
              container: '#klarna-payments-container',
              payment_method_category: 'pay_later',
            },
            cartParams.klarna.klarna_cart,
            function (res) {
              setShowAuthorizeBtn(res.show_form);

              window.parent.postMessage(
                {
                  type: 'EXTERNAL_PAYMENT_GATEWAY_UPDATE_HEIGHT',
                  payload: {
                    success: true,
                    height: 1000,
                    width: window.innerWidth,
                  },
                },
                '*'
              );

              if (authorizeButtonRef.current) {
                authorizeButtonRef.current.scrollIntoView({ behavior: 'smooth' });
              }
            }
          );
        }
      } catch (error) {
        console.log('error', error);
      }
    };

    window.addEventListener('message', handleMessage);

    return () => {
      window.removeEventListener('message', handleMessage);
    };
  }, [applicationState]);

  return (
    <div>
      {showWidget && <div id="klarna-payments-container" className={styles.klarnaContainer}></div>}
      <div ref={authorizeButtonRef}> {/* Scroll target */}
        {showAuthorizeBtn && (
          <Button onClick={authorizePayment} variant="contained" color="primary">
            Checkout With Klarna
          </Button>
        )}
      </div>
    </div>
  );
}
