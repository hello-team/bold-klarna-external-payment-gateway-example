import React from 'react';
import { createRoot } from 'react-dom/client'; // Import the createRoot method
import App from './App';

// Use createRoot instead of ReactDOM.render
createRoot(document.getElementById('klarna-div')).render(
  <React.StrictMode>
    <App />
  </React.StrictMode>
);
