import React, { useEffect } from 'react';
import PaymentWidget from './PaymentWidget';
import styles from './styles/klarna-checkout-component.module.css';

const App = () => {
  useEffect(() => {
    window.parent.postMessage(
      {
        actionType: 'MEDIA',
        payload: {
          height: window.innerHeight,
        },
      },
      '*'
    );
  }, []);

  return (
    <div>
      <button className={styles['klarna-payment-button']}>Klarna Payment Button</button>
      <div id="klarna-widget">
        <PaymentWidget />
      </div>
    </div>
  );
};

export default App;
