import React, { useEffect, useState } from 'react';
import styles from './styles/klarna-checkout-component.module.css';

export default function PaymentWidget() {
  const [showAuthorizeBtn, setShowAuthorizeBtn] = useState(false);
  const [klarnaCart, setKlarnaCart] = useState(null);
  const [isAuthorized, setIsAuthorized] = useState(false);

  const completePurchase = () => {
    window.parent.postMessage(
      {
        responseType: 'TOKENIZING_COMPLETE',
        payload: {
          success: true,
        },
      },
      '*'
    );
  };

  const authorizePayment = (event) => {
    event.preventDefault();

    window.Klarna.Payments.authorize(
      {
        payment_method_category: 'pay_over_time',
      },
      klarnaCart,
      function (res) {
        const authorization_token = res.authorization_token;
        if (authorization_token && !isAuthorized) {
          setIsAuthorized(true);
          window.parent.postMessage(
            {
              responseType: 'ADD_PAYMENT',
              payload: {
                success: true,
                paymentType: 'CREDIT_CARD',
                height: window.innerHeight,
              },
            },
            '*'
          );
          completePurchase();
        }
      }
    );
  };

  useEffect(() => {
    const handleMessage = (event) => {
      try {
        const message = event.data;
        const cartParams = message?.payload?.order_meta_data?.cart_parameters;

        if (cartParams && cartParams.klarna && window.Klarna) {
          setKlarnaCart(cartParams.klarna.klarna_cart);
          const klarnaToken = cartParams.klarna.client_token;

          window.Klarna.Payments.init({ client_token: klarnaToken });

          window.Klarna.Payments.load(
            {
              container: '#klarna-payments-container',
              payment_method_category: 'pay_over_time',
            },
            cartParams.klarna.klarna_cart,
            function (res) {
              setShowAuthorizeBtn(res.show_form);
              window.parent.postMessage(
                {
                  actionType: 'MEDIA',
                  payload: {
                    success: true,
                    height: window.innerHeight,
                  },
                },
                '*'
              );
            }
          );
        }
      } catch (error) {
        console.log('error', error);
      }
    };

    window.addEventListener('message', handleMessage);

    return () => {
      window.removeEventListener('message', handleMessage);
    };
  }, []);

  return (
    <div style={{ display: 'flex-inline' }}>
      <div id="klarna-payments-container" className={styles.klarnaContainer}></div>
      {showAuthorizeBtn && (
        <button onClick={authorizePayment} className={styles.authorizeBtn}>
          Authorize Payment
        </button>
      )}
    </div>
  );
}
